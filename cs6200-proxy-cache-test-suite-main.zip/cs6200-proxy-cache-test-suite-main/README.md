# CS6200 Proxy–Cache Test Suite

## Overview
This repository provides automated test scripts for validating the CS6200 Project 3 (Proxy + Cache IPC System).

It tests cache hit/miss logic, concurrency handling and resilience to startup order.

## Usage

```bash
cd cache
mkdir temp
cd temp
git clone git@github.gatech.edu:gios-fall-25/cs6200-proxy-cache-test-suite.git
cd cs6200-proxy-cache-test-suite.git
chmod +x run_all_tests.sh
cd ../..
bash temp/cs6200-proxy-cache-test-suite/run_all_tests.sh
```

![alt text](image.png)