#!/bin/bash
# Test cache miss handling

PORT=25362

./simplecached &
CACHE_PID=$!
sleep 2

./webproxy -p $PORT &
PROXY_PID=$!
sleep 2

# Run client thrice
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 2
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 2
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 2

kill -9 $PROXY_PID $CACHE_PID
