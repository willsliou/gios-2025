#!/bin/bash
# Test cache hit scenario

PORT=25362


# Start cache daemon
./simplecached &
CACHE_PID=$!
sleep 2

# Start proxy
./webproxy -p $PORT &
PROXY_PID=$!
sleep 20

# Run client thrice
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 1
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 1
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 1