"""
Getfile Test Client for Abnormal and Cache Validation Cases
Author: Gayatri Nair
Date: 2025-11-02
"""

import socket
import sys
import time

DEFAULT_PROXY_HOST = "127.0.0.1"
DEFAULT_PROXY_PORT = 25362

# Expected response headers
GF_OK = b"GETFILE OK"
GF_FILE_NOT_FOUND = b"GETFILE FILE_NOT_FOUND"
GF_ERROR = b"GETFILE ERROR"


def send_to_server(request):
    """Send a raw GETFILE request to the proxy and check its response."""

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", DEFAULT_PROXY_PORT))

    s.send(request)

    try:
        response = s.recv(4096)
        print(f"\n[DEBUG] Raw Response: {response[:80]}{'...' if len(response) > 80 else ''}")

        if GF_OK in response:
            print("Test Passed — Received GF_OK (Cache HIT or Remote Fetch Success)")
        elif GF_FILE_NOT_FOUND in response:
            print("Cache MISS — File not found in cache (GF_FILE_NOT_FOUND)")
        elif GF_ERROR in response:
            print("Test Failed — GF_ERROR returned (Server-side error)")
        else:
            print("Unexpected response format")
    except Exception as e:
        print(f"Exception while receiving: {e}")
    finally:
        try:
            s.settimeout(0.2)  # short timeout to avoid blocking
            while True:
                data = s.recv(4096)
                if not data:
                    break  # EOF -> connection closed
        except (socket.timeout, ConnectionResetError, OSError):
            # Expected when the server closes or times out
            pass
        finally:
            s.close()


if __name__ == "__main__":
    option = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    print(f"Running option {option}...\n")

    if option == 1:
        print("Test: Known files — expecting GF_OK (Cache HIT or Remote Fetch Success)")
        for f in [
            b"/courses/ud923/filecorpus/paraglider.jpg",
            b"/courses/ud923/filecorpus/road.jpg",
            b"/courses/ud923/filecorpus/yellowstone.jpg",
        ]:
            req = b"GETFILE GET " + f + b"\r\n\r\n"
            send_to_server(req)
            time.sleep(2)

    elif option == 2:
        # ⚠️ Option 2: Cache Miss (should return FILE_NOT_FOUND)
        print("Test: Random non-existent file — expecting GF_FILE_NOT_FOUND")
        req = b"GETFILE GET /randomfile.txt\r\n\r\n"
        send_to_server(req)

    elif option == 3:
        # 🔁 Option 3: Mixed repeated requests (tests cache reuse and hit ratio)
        print("Test: Mixed requests — ensures cache reuse and consistency")
        for i in range(2):  # repeat twice to ensure second run is cached
            for f in [
                b"/courses/ud923/filecorpus/paraglider.jpg",
                b"/courses/ud923/filecorpus/road.jpg",
                b"/courses/ud923/filecorpus/yellowstone.jpg",
                b"/courses/ud923/filecorpus/moranabovejacksonlake.jpg",
                b"/randomfile.txt",
            ]:
                print(f"\n🔁 Iteration {i+1}, Request: {f.decode()}")
                req = b"GETFILE GET " + f + b"\r\n\r\n"
                send_to_server(req)
                time.sleep(0.5)

    else:
        print("Usage: python3 gfclient_test.py <option_number>")
