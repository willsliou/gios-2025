#!/bin/bash
# Stress test for Proxy–Cache IPC synchronization

PORT=25362
NUM_CLIENTS=30
WORKLOAD_FILE="workload.txt"

# Start cache daemon in background
./simplecached &
CACHE_PID=$!
sleep 2

# Start proxy server
./webproxy -p $PORT -n 4 -z 65536 &
PROXY_PID=$!
sleep 2


echo "Launching $NUM_CLIENTS concurrent clients..."
CLIENT_PIDS=()
for i in $(seq 1 $NUM_CLIENTS); do
    echo " → Client $i requesting"
    ./gfclient_download -p $PORT &
    CLIENT_PIDS+=($!)
done

# Wait for all clients
echo "⏳ Waiting for clients to finish..."
for pid in "${CLIENT_PIDS[@]}"; do
    wait "$pid"
done

echo " All clients completed."

# Cleanup
kill -INT $PROXY_PID
kill -INT $CACHE_PID
wait

echo "Stress test completed successfully."
