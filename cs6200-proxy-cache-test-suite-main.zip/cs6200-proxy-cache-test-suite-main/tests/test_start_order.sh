#!/bin/bash
# Test start order robustness

PORT=25362

# Start proxy first (cache delayed)
./webproxy -p $PORT &
PROXY_PID=$!
sleep 5

# Then start cache
./simplecached  &
CACHE_PID=$!
sleep 5

# Run client thrice
python3 temp/cs6200-proxy-cache-test-suite/tests/gfclient_test.py 3

kill -9 $PROXY_PID $CACHE_PID

echo "Start order test completed"
exit 0
