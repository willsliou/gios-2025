#!/bin/bash
# Run all proxy-cache integration tests
# Author: Gayatri Nair

LOG_DIR="results/logs"
mkdir -p "$LOG_DIR"

TESTS=("test_cache_hit" "test_cache_miss" "test_stress_testing" "test_start_order")

echo "=== Starting Proxy-Cache Test Suite ==="

for test in "${TESTS[@]}"; do
  echo "[RUNNING] $test"
  bash "temp/cs6200-proxy-cache-test-suite/tests/${test}.sh" > "${LOG_DIR}/${test}.log" 2>&1
  if [ $? -eq 0 ]; then
    echo "[PASS] $test"
  else
    echo "[FAIL] $test (see ${LOG_DIR}/${test}.log)"
  fi
  sleep 30
done

echo "=== All tests completed ==="
